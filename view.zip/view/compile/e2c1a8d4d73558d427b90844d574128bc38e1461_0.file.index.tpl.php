<?php
/* Smarty version 3.1.44, created on 2022-02-14 22:57:20
  from 'D:\XAMPP\htdocs\lojaVirtual\view\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.44',
  'unifunc' => 'content_620ad040aecd08_97189325',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e2c1a8d4d73558d427b90844d574128bc38e1461' => 
    array (
      0 => 'D:\\XAMPP\\htdocs\\lojaVirtual\\view\\index.tpl',
      1 => 1644875731,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_620ad040aecd08_97189325 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    Esta e a pagina carregada com o samrty
    <h2><?php echo $_smarty_tpl->tpl_vars['NOME']->value;?>
</h2>
</body>
</html><?php }
}
