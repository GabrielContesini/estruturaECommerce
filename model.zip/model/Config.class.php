<?php

    Class Config {

        //infos basicas para o site

        const SITE_URL = "http://localhost";
        const SITE_PASTA = "lojaVirtual";
        const SITE_NOME = "Loja  Virtual";
        const SITE_EMAIL_ADMIN = "gabrielct.moraes@gmail.com";

        //infos para o banco de dados

        const BD_HOST = "localhost",
            BD_USER ="root",
            BD_SENHA = "",
            BD_BANCO = "lojavirtual";
            


        //infos para o php mailler

        const EMAIL_HOST = "smtp.gmail.com";
        const EMAIL_USER = "gabrielct.moraes@gmail.com";
        const EMAIL_NOME = "contato loja virtual";
        const EMAIL_SENHA = "lojavirtual";
        const EMAIL_PORTA = 587;
        const EMAIL_SMTP = true;
        const EMAIL_SMTPSECURE = "tls";
        const EMAIL_COPIA = "gabrielct.moraes@gmail.com";
    }
?>